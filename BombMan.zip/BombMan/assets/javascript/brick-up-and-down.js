cc.Class({
    extends: cc.Component,

    properties: {
       distance:0,
       s:1,
       maxDistance:25,
       speed:0.3
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    update (dt) {
        
        if(this.distance<this.maxDistance){
            if(this.s==1){
                this.node.y=this.node.y+this.speed;
            }else{
                this.node.y=this.node.y-this.speed;
            }
            this.distance= this.distance+this.speed;
        }else{
            this.distance=0;
            this.s=-this.s;
        }
        
    },
});
