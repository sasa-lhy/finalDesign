cc.Class({
    extends: cc.Component,

    properties: {
    },

    onLoad () {
    	 this.end=true;
    },

    start () {
       
    },

    update (dt) {
    	this.node._components[0].fillRange -= 0.0001;
    	if(this.node._components[0].fillRange<0.1){
    		this.node.color=this.node.color.setG(0);
    		this.node.color=this.node.color.setB(0);
    	}
        if(this.end && this.node._components[0].fillRange<=0 ){
            this.end = false;
            cc.director.loadScene("gameover");
        }

    },
});
