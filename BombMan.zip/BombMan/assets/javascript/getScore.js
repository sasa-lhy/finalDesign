
cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
       
        this.getComponent(cc.Label).string='分      数：'+cc.find('persistNode').score;
    },

    // update (dt) {},
});
