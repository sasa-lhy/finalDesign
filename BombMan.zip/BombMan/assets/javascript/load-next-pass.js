cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.node.on('touchend',function(event){
            cc.director.loadScene('play'+(cc.find('persistNode').level+1),function(){
               cc.find('persistNode').level++;
            });
        },this);
    },

    // update (dt) {},
});
