
cc.Class({
    extends: cc.Component,

    properties: {
        player:{
            type:cc.Node,
            default:null
        },
        speed:10
    },

    // LIFE-CYCLE CALLBACKS:

    changeDir () {
        switch (this.direction){
            case 'left':
            this.node._children[1]._components[0].fillStart=0.375;
            this.node._children[1]._components[0].fillRange=0.25;
            this.player.getComponent(cc.RigidBody).linearVelocity={
                x:-this.speed,
                y:-this.speed*0.57
            };
            break;
            case "right":
            this.node._children[1]._components[0].fillStart=0.875;
            this.node._children[1]._components[0].fillRange=0.25;
            this.player.getComponent(cc.RigidBody).linearVelocity={
                x:this.speed,
                y:this.speed*0.57
            };
            break;
            case 'down':
            this.node._children[1]._components[0].fillStart=0.625;
            this.node._children[1]._components[0].fillRange=0.25;
            this.player.getComponent(cc.RigidBody).linearVelocity={
                x:this.speed,
                y:-this.speed*0.57
            };
            break;
            case "up":
            this.node._children[1]._components[0].fillStart=0.125;
            this.node._children[1]._components[0].fillRange=0.25;
            this.player.getComponent(cc.RigidBody).linearVelocity={
                x:-this.speed,
                y:this.speed*0.57
            };
            break;
            default:
            this.node._children[1]._components[0].fillStart=0;
            this.node._children[1]._components[0].fillRange=0;
            this.player.getComponent(cc.RigidBody).linearVelocity={
                x:0,
                y:0
            };
            break;
        }
        console.log(this.direction);
    },

    onLoad () {
        this.direction="";
        this.node.on('touchstart',function(e){
            var pos=this.node.convertToNodeSpaceAR(cc.v2(e.getLocationX(), e.getLocationY()));
            if(pos.y>pos.x && pos.y>-pos.x){
                this.direction="up";
            }else if(-pos.y>pos.x && -pos.y>-pos.x){
                this.direction="down"; 
            }else if(pos.x>pos.y && pos.x>pos.y){
                this.direction="right";
            }else if(-pos.x>-pos.y && -pos.x>pos.y){
                 this.direction="left";
            }
            this.changeDir();
        },this);
        
        this.node.on('touchmove',function(e){
            var pos=this.node.convertToNodeSpaceAR(cc.v2(e.getLocationX(), e.getLocationY()));
            if(pos.y>pos.x && pos.y>-pos.x){
                this.direction="up";
            }else if(-pos.y>pos.x && -pos.y>-pos.x){
                this.direction="down"; 
            }else if(pos.x>pos.y && pos.x>pos.y){
                this.direction="right";
            }else if(-pos.x>-pos.y && -pos.x>pos.y){
                 this.direction="left";
            }
            this.changeDir();
        },this);

        //取消运动
        this.node.on('touchend',function(e){
            this.direction="";
            this.changeDir();
        },this);

        this.node.on('touchcancel',function(e){
            this.direction="";
            this.changeDir();
        },this);
    },

    start () {

    },

    // update (dt) {},
});
