cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        cc.game.addPersistRootNode(this.node);
        this.node.level=0;
        this.node.score=0;
    },

    start () {

    },

    update (dt) {},
});
