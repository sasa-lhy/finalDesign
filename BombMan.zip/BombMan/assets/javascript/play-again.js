
cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.node.on('touchend',function(e){
            console.log(cc.find('persistNode'));
            cc.director.loadScene('play'+cc.find('persistNode').level,function(){
               cc.find('persistNode').score=0;
            });
        },this)
    },

    // update (dt) {},
});
