
cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.begin=false;
        this.node.on('getBox',function(){
           console.log('翻转砖块！');
           this.begin=true;
        },this);
    },
    onCollisionStay: function (other, self) {

        if(this.begin){
            setTimeout(function () {
                other.node.emit('do-box');
            }.bind(other.node), 2000);
        }
        this.begin=false;
    },

    // update (dt) {},
});
