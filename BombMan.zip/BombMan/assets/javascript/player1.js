
cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },
    onBeginContact: function (contact, selfCollider, otherCollider) {
        if(otherCollider.node.group==='fog'){
            cc.director.loadScene("gameover");
        }
       console.log(otherCollider.node);
    },
    // update (dt) {},
});
