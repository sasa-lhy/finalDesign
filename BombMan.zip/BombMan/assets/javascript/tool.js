
cc.Class({
    extends: cc.Component,

    properties: {
        
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.begin=0;
        this.anim=true;
    },

    start () {
        this.begin=0;
    },
    //碰撞开始：解决两个节点互相遮盖的问题
    onCollisionEnter: function (other, self) {
        if(self.world.aabb.y>other.world.aabb.y){
            other.node.zIndex=1;
            self.node.zIndex=0;
        }else{
            other.node.zIndex=0;
            self.node.zIndex=1;
        }
    },
    //持续碰撞期间
    onCollisionStay: function (other, self) {
        if(self.world.aabb.y>other.world.aabb.y){
            other.node.zIndex=1;
            self.node.zIndex=0;
        }else{
            other.node.zIndex=0;
            self.node.zIndex=1;
        }
    },
    //碰撞结束
    onCollisionExit: function (other, self) {
        other.node.zIndex=0;
        self.node.zIndex=0;
    },
    onBeginContact: function (contact, selfCollider, otherCollider) {
        if(otherCollider.node.group==='fog'){
            otherCollider.node.destroy();
            cc.find("Canvas").fognum--;
        }
    },
    //生成的节点20s后销毁
    update (dt) {
        if(this.begin<20){
            this.begin+=dt
            if(this.begin>17 && this.anim){
                 this.getComponent(cc.Animation).play();
                 this.anim=false;
            }
        }else{
            this.node.destroy();
        }
    },
});
