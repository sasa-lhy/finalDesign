"use strict";
cc._RF.push(module, '00b74YeiB1HIJBIsp8IItER', 'persist');
// javascript/persist.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        cc.game.addPersistRootNode(this.node);
        this.node.level = 0;
        this.node.score = 0;
    },
    start: function start() {},
    update: function update(dt) {}
});

cc._RF.pop();