"use strict";
cc._RF.push(module, '0387axHWbtHAonV6aL4plX7', 'player1');
// javascript/player1.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        if (otherCollider.node.group === 'fog') {
            cc.director.loadScene("gameover");
        }
        console.log(otherCollider.node);
    }
    // update (dt) {},
});

cc._RF.pop();