"use strict";
cc._RF.push(module, '12e67dx/KBJt49rZTx0byts', 'common');
// javascript/common.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        fognum: 0
    },

    onLoad: function onLoad() {
        //开启物理系统
        cc.director.getPhysicsManager().enabled = true;
        //设置重力加速度为0
        cc.director.getPhysicsManager().gravity = cc.v2();
        //开启碰撞系统
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        this.node.fognum = this.fognum;
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();