"use strict";
cc._RF.push(module, '14ef4sPlDFAW7Lm6V/+YIaG', 'back-to-level');
// javascript/back-to-level.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on('touchend', function (e) {
            console.log('进入关卡页！');
            cc.director.loadScene('level', function () {
                cc.find('persistNode').level = 0;
                cc.find('persistNode').score = 0;
            });
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();