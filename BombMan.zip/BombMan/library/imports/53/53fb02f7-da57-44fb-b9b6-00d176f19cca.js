"use strict";
cc._RF.push(module, '53fb0L32ldE+7m2ANF28ZzK', 'do-double-click');
// javascript/do-double-click.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        player: {
            type: cc.Node,
            default: null
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {},
    start: function start() {
        this.touchTime = new Date();
        this.moveBegin = false;
        this.move = false;
        console.log(this.touchTime);
        console.log(this.touchTime.getTime());
        this.node.on('touchstart', function (event) {
            console.log('touchstart!');
            this.moveBegin = true;
            var a = new Date();
            if (a.getTime() - this.touchTime.getTime() < 1000) {
                this.moveBegin = false;
                this.node.emit('doubletouch');
            } else {
                this.touchTime = a;
            }
        }, this);

        this.node.on('touchmove', function (event) {
            console.log('touchmove!');
            this.move = true;
        }, this);

        this.node.on('touchend', function (event) {
            console.log('touchend!');
            if (this.moveBegin && this.move) {

                if (event.touch._startPoint.y < event.touch._point.y && event.touch._startPoint.x < event.touch._point.x) {
                    //this.node.emit('move','东北');
                }
                if (event.touch._startPoint.y > event.touch._point.y && event.touch._startPoint.x > event.touch._point.x) {
                    //this.node.emit('move','西南');
                }
                if (event.touch._startPoint.y > event.touch._point.y && event.touch._startPoint.x < event.touch._point.x) {
                    //this.node.emit('move','东南');
                }
                if (event.touch._startPoint.y < event.touch._point.y && event.touch._startPoint.x > event.touch._point.x) {
                    //this.node.emit('move','西北');
                }
            }
            this.moveBegin = false;
            this.move = false;
        }, this);

        //自定义事件
        this.node.on('doubletouch', function () {
            console.log('doubletouch!');
            this.emit('getBox');
        }, this.player.children[0]);

        //此自定义事件弃用
        this.node.on('move', function (dir) {
            if (this.getComponent(cc.RigidBody).linearVelocity.x == 0 && this.getComponent(cc.RigidBody).linearVelocity.y == 0) {
                this.speed = 60;
                console.log('do move:' + dir);
                switch (dir) {
                    case '东北':
                        this.getComponent(cc.RigidBody).linearVelocity = {
                            x: this.speed,
                            y: this.speed * 0.577
                        };
                        break;

                    case '西南':
                        this.getComponent(cc.RigidBody).linearVelocity = {
                            x: -this.speed,
                            y: -this.speed * 0.577
                        };
                        break;

                    case '东南':
                        this.getComponent(cc.RigidBody).linearVelocity = {
                            x: this.speed,
                            y: -this.speed * 0.577
                        };
                        break;

                    case '西北':
                        this.getComponent(cc.RigidBody).linearVelocity = {
                            x: -this.speed,
                            y: this.speed * 0.577
                        };
                        break;
                }
            }
        }, this.player);
    }
}

// update (dt) {},
);

cc._RF.pop();