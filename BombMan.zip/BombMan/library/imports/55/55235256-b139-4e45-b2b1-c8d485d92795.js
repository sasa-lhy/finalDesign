"use strict";
cc._RF.push(module, '55235JWsTlORbKxyNSF2SeV', 'getBox');
// javascript/getBox.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        target: {
            default: null,
            type: cc.Prefab
        },
        target1: {
            default: null,
            type: cc.Prefab
        },
        target2: {
            default: null,
            type: cc.Prefab
        },
        door: {
            default: null,
            type: cc.Prefab
        },

        No: 0
    },

    // onLoad () {},

    start: function start() {
        this.parentTar = cc.find("Mover");
        this.node.on('do-box', function () {
            console.log(this.node.convertToWorldSpace(this.node.x, this.node.y));
            var p = this.node.convertToWorldSpace(this.node.x, this.node.y);
            if (this.No === 1) {
                this.node._parent.getComponent(cc.Animation).play();
                var node = cc.instantiate(this.target);
                node.parent = this.parentTar;
                node.setPosition(p);
                this.No = 0;
            }
            if (this.No === 2) {
                this.node._parent.getComponent(cc.Animation).play();
                var node = cc.instantiate(this.target1);
                node.parent = this.parentTar;
                node.setPosition(p);
                this.No = 0;
            }
            if (this.No === 3) {
                this.node._parent.getComponent(cc.Animation).play();
                var node = cc.instantiate(this.target2);
                node.parent = this.parentTar;
                node.setPosition(p);
                this.No = 0;
            }
            if (this.No === 6) {
                this.node._parent.getComponent(cc.Animation).play();
                var node = cc.instantiate(this.door);
                var parent = this.node.parent;
                while (parent.children.length > 0) {
                    if (parent.children.length === 3) {
                        var funNode = parent.children.pop();
                    } else {
                        parent.children.pop();
                    }
                }
                parent.children.push(node);
                parent.children.push(funNode);
                node.parent = parent;
                funNode.parent = parent;
                parent._children[0].x = 0;
                parent._children[0].y = 0;
                this.No = 0;
                console.log(node);
            }
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();