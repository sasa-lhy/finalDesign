"use strict";
cc._RF.push(module, '606e4D6EH1Jb6igxKxW3tnB', 'enter-level');
// javascript/enter-level.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        No: 0
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on('touchend', function (event) {
            console.log('进入关卡:' + this.No);
            var no = this.No;
            cc.director.loadScene('play' + this.No, function () {
                cc.find('persistNode').level = no;
                console.log(cc.find('persistNode'));
            });
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();