"use strict";
cc._RF.push(module, '7e9bdB40EhP5IeK6FOmZLbS', 'play-again');
// javascript/play-again.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on('touchend', function (e) {
            console.log(cc.find('persistNode'));
            cc.director.loadScene('play' + cc.find('persistNode').level, function () {
                cc.find('persistNode').score = 0;
            });
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();