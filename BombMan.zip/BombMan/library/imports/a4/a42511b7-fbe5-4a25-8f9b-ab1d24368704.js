"use strict";
cc._RF.push(module, 'a4251G3++VKJY+bqx0kNocE', 'getScore');
// javascript/getScore.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {

        this.getComponent(cc.Label).string = '分      数：' + cc.find('persistNode').score;
    }
}

// update (dt) {},
);

cc._RF.pop();