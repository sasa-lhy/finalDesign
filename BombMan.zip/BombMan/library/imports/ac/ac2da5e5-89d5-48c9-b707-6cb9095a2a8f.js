"use strict";
cc._RF.push(module, 'ac2daXlidVIybcHbLkJWiqP', 'count-down');
// javascript/count-down.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.end = true;
    },
    start: function start() {},
    update: function update(dt) {
        this.node._components[0].fillRange -= 0.0001;
        if (this.node._components[0].fillRange < 0.1) {
            this.node.color = this.node.color.setG(0);
            this.node.color = this.node.color.setB(0);
        }
        if (this.end && this.node._components[0].fillRange <= 0) {
            this.end = false;
            cc.director.loadScene("gameover");
        }
    }
});

cc._RF.pop();