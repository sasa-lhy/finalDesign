"use strict";
cc._RF.push(module, 'b44b1pNCaVEJIXsmxuNVIdW', 'door');
// javascript/door.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        console.log('hhh');
        if (otherCollider.node.group === 'player') {
            console.log(cc.find("Canvas"));
            if (cc.find("Canvas").fognum <= 0) {
                var score = cc.find('UI/time2/time1')._components[0].fillRange * 100;
                cc.director.loadScene('gamepass', function () {
                    console.log(cc.find('UI/time2/time1'));
                    cc.find('persistNode').score = parseInt(score);
                });
            }
        }
    }

    // update (dt) {},
});

cc._RF.pop();