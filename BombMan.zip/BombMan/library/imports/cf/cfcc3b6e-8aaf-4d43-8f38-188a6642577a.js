"use strict";
cc._RF.push(module, 'cfcc3tuiq9NQ484GIpmQld6', 'load-next-pass');
// javascript/load-next-pass.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on('touchend', function (event) {
            cc.director.loadScene('play' + (cc.find('persistNode').level + 1), function () {
                cc.find('persistNode').level++;
            });
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();