"use strict";
cc._RF.push(module, 'dfedcuLjm5CbLVEv+TR1663', 'start-btn-anim');
// javascript/start-btn-anim.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        size: 0,
        s: 1
    },

    // LIFE-CYCLE CALLBACKS:
    // onLoad () {},
    start: function start() {

        this.node.on('touchend', function (event) {
            console.log('选择关卡！');
            cc.director.loadScene('level');
        }, this);
    },
    update: function update(dt) {

        if (this.node.scale <= 0.52) {
            this.node.scale = this.node.scale + dt / 5;
        } else {
            this.node.scale = 0.42;
        }

        if (this.size < 0.5) {
            if (this.s == 1) {
                this.node.y = this.node.y + dt / 5;
            } else {
                this.node.y = this.node.y - dt / 5;
            }
            this.size = this.size + dt / 5;
        } else {
            this.size = 0;
            this.s = -this.s;
        }
    }
});

cc._RF.pop();