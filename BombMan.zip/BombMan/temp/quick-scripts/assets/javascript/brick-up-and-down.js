(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/brick-up-and-down.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'd2b83r6k+dPpJhRWF9FXo4C', 'brick-up-and-down', __filename);
// javascript/brick-up-and-down.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        distance: 0,
        s: 1,
        maxDistance: 25,
        speed: 0.3
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    update: function update(dt) {

        if (this.distance < this.maxDistance) {
            if (this.s == 1) {
                this.node.y = this.node.y + this.speed;
            } else {
                this.node.y = this.node.y - this.speed;
            }
            this.distance = this.distance + this.speed;
        } else {
            this.distance = 0;
            this.s = -this.s;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=brick-up-and-down.js.map
        