(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/common.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '12e67dx/KBJt49rZTx0byts', 'common', __filename);
// javascript/common.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        fognum: 0
    },

    onLoad: function onLoad() {
        //开启物理系统
        cc.director.getPhysicsManager().enabled = true;
        //设置重力加速度为0
        cc.director.getPhysicsManager().gravity = cc.v2();
        //开启碰撞系统
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        this.node.fognum = this.fognum;
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=common.js.map
        