(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/count-down.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ac2daXlidVIybcHbLkJWiqP', 'count-down', __filename);
// javascript/count-down.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.end = true;
    },
    start: function start() {},
    update: function update(dt) {
        this.node._components[0].fillRange -= 0.0001;
        if (this.node._components[0].fillRange < 0.1) {
            this.node.color = this.node.color.setG(0);
            this.node.color = this.node.color.setB(0);
        }
        if (this.end && this.node._components[0].fillRange <= 0) {
            this.end = false;
            cc.director.loadScene("gameover");
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=count-down.js.map
        