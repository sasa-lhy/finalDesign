(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/enter-level.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '606e4D6EH1Jb6igxKxW3tnB', 'enter-level', __filename);
// javascript/enter-level.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        No: 0
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on('touchend', function (event) {
            console.log('进入关卡:' + this.No);
            var no = this.No;
            cc.director.loadScene('play' + this.No, function () {
                cc.find('persistNode').level = no;
                console.log(cc.find('persistNode'));
            });
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=enter-level.js.map
        