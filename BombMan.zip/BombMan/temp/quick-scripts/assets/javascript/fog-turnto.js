(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/fog-turnto.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '1c5a98mt21LIJPu4XtIhPSe', 'fog-turnto', __filename);
// javascript/fog-turnto.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        speed: 20
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        console.log(this);
    },


    //碰撞开始：解决两个节点互相遮盖的问题
    onCollisionEnter: function onCollisionEnter(other, self) {
        if (self.world.aabb.y > other.world.aabb.y) {
            other.node.zIndex = 1;
            self.node.zIndex = 0;
        } else {
            other.node.zIndex = 0;
            self.node.zIndex = 1;
        }
    },
    //持续碰撞期间
    onCollisionStay: function onCollisionStay(other, self) {
        if (self.world.aabb.y > other.world.aabb.y) {
            other.node.zIndex = 1;
            self.node.zIndex = 0;
        } else {
            other.node.zIndex = 0;
            self.node.zIndex = 1;
        }
    },
    //碰撞结束
    onCollisionExit: function onCollisionExit(other, self) {
        other.node.zIndex = 0;
        self.node.zIndex = 0;
    },

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        var selfV = selfCollider.body.linearVelocity;
        if (selfV.x < 0) {
            selfV.x = this.speed;
        } else {
            selfV.x = -this.speed;
        }
        if (selfV.y < 0) {
            selfV.y = this.speed * 0.577;
        } else {
            selfV.y = -this.speed * 0.577;
        }
        selfCollider.body.linearVelocity = cc.v2(selfV.x, selfV.y);
    }

    // update (dt) {
    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=fog-turnto.js.map
        