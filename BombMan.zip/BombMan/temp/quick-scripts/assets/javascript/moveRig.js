(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/moveRig.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '667faZQEpBKELRyB2D2NKC3', 'moveRig', __filename);
// javascript/moveRig.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        player: {
            type: cc.Node,
            default: null
        },
        speed: 10
    },

    // LIFE-CYCLE CALLBACKS:

    changeDir: function changeDir() {
        switch (this.direction) {
            case 'left':
                this.node._children[1]._components[0].fillStart = 0.375;
                this.node._children[1]._components[0].fillRange = 0.25;
                this.player.getComponent(cc.RigidBody).linearVelocity = {
                    x: -this.speed,
                    y: -this.speed * 0.57
                };
                break;
            case "right":
                this.node._children[1]._components[0].fillStart = 0.875;
                this.node._children[1]._components[0].fillRange = 0.25;
                this.player.getComponent(cc.RigidBody).linearVelocity = {
                    x: this.speed,
                    y: this.speed * 0.57
                };
                break;
            case 'down':
                this.node._children[1]._components[0].fillStart = 0.625;
                this.node._children[1]._components[0].fillRange = 0.25;
                this.player.getComponent(cc.RigidBody).linearVelocity = {
                    x: this.speed,
                    y: -this.speed * 0.57
                };
                break;
            case "up":
                this.node._children[1]._components[0].fillStart = 0.125;
                this.node._children[1]._components[0].fillRange = 0.25;
                this.player.getComponent(cc.RigidBody).linearVelocity = {
                    x: -this.speed,
                    y: this.speed * 0.57
                };
                break;
            default:
                this.node._children[1]._components[0].fillStart = 0;
                this.node._children[1]._components[0].fillRange = 0;
                this.player.getComponent(cc.RigidBody).linearVelocity = {
                    x: 0,
                    y: 0
                };
                break;
        }
        console.log(this.direction);
    },
    onLoad: function onLoad() {
        this.direction = "";
        this.node.on('touchstart', function (e) {
            var pos = this.node.convertToNodeSpaceAR(cc.v2(e.getLocationX(), e.getLocationY()));
            if (pos.y > pos.x && pos.y > -pos.x) {
                this.direction = "up";
            } else if (-pos.y > pos.x && -pos.y > -pos.x) {
                this.direction = "down";
            } else if (pos.x > pos.y && pos.x > pos.y) {
                this.direction = "right";
            } else if (-pos.x > -pos.y && -pos.x > pos.y) {
                this.direction = "left";
            }
            this.changeDir();
        }, this);

        this.node.on('touchmove', function (e) {
            var pos = this.node.convertToNodeSpaceAR(cc.v2(e.getLocationX(), e.getLocationY()));
            if (pos.y > pos.x && pos.y > -pos.x) {
                this.direction = "up";
            } else if (-pos.y > pos.x && -pos.y > -pos.x) {
                this.direction = "down";
            } else if (pos.x > pos.y && pos.x > pos.y) {
                this.direction = "right";
            } else if (-pos.x > -pos.y && -pos.x > pos.y) {
                this.direction = "left";
            }
            this.changeDir();
        }, this);

        //取消运动
        this.node.on('touchend', function (e) {
            this.direction = "";
            this.changeDir();
        }, this);

        this.node.on('touchcancel', function (e) {
            this.direction = "";
            this.changeDir();
        }, this);
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=moveRig.js.map
        