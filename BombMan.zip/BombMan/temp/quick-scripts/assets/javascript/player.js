(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/player.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dc615IvOoRDnLAAA7ZSfmQE', 'player', __filename);
// javascript/player.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.begin = false;
        this.node.on('getBox', function () {
            console.log('翻转砖块！');
            this.begin = true;
        }, this);
    },

    onCollisionStay: function onCollisionStay(other, self) {

        if (this.begin) {
            setTimeout(function () {
                other.node.emit('do-box');
            }.bind(other.node), 2000);
        }
        this.begin = false;
    }

    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=player.js.map
        