(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/start-btn-anim.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'dfedcuLjm5CbLVEv+TR1663', 'start-btn-anim', __filename);
// javascript/start-btn-anim.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        size: 0,
        s: 1
    },

    // LIFE-CYCLE CALLBACKS:
    // onLoad () {},
    start: function start() {

        this.node.on('touchend', function (event) {
            console.log('选择关卡！');
            cc.director.loadScene('level');
        }, this);
    },
    update: function update(dt) {

        if (this.node.scale <= 0.52) {
            this.node.scale = this.node.scale + dt / 5;
        } else {
            this.node.scale = 0.42;
        }

        if (this.size < 0.5) {
            if (this.s == 1) {
                this.node.y = this.node.y + dt / 5;
            } else {
                this.node.y = this.node.y - dt / 5;
            }
            this.size = this.size + dt / 5;
        } else {
            this.size = 0;
            this.s = -this.s;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=start-btn-anim.js.map
        