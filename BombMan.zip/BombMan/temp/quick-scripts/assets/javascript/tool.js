(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/javascript/tool.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '26d2bP1GiBBs71ppmTtnHrt', 'tool', __filename);
// javascript/tool.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.begin = 0;
        this.anim = true;
    },
    start: function start() {
        this.begin = 0;
    },

    //碰撞开始：解决两个节点互相遮盖的问题
    onCollisionEnter: function onCollisionEnter(other, self) {
        if (self.world.aabb.y > other.world.aabb.y) {
            other.node.zIndex = 1;
            self.node.zIndex = 0;
        } else {
            other.node.zIndex = 0;
            self.node.zIndex = 1;
        }
    },
    //持续碰撞期间
    onCollisionStay: function onCollisionStay(other, self) {
        if (self.world.aabb.y > other.world.aabb.y) {
            other.node.zIndex = 1;
            self.node.zIndex = 0;
        } else {
            other.node.zIndex = 0;
            self.node.zIndex = 1;
        }
    },
    //碰撞结束
    onCollisionExit: function onCollisionExit(other, self) {
        other.node.zIndex = 0;
        self.node.zIndex = 0;
    },
    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        if (otherCollider.node.group === 'fog') {
            otherCollider.node.destroy();
            cc.find("Canvas").fognum--;
        }
    },
    //生成的节点20s后销毁
    update: function update(dt) {
        if (this.begin < 20) {
            this.begin += dt;
            if (this.begin > 17 && this.anim) {
                this.getComponent(cc.Animation).play();
                this.anim = false;
            }
        } else {
            this.node.destroy();
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=tool.js.map
        